package com.hospital.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hospital.entity.Appointment;
import com.hospital.entity.User;
import com.hospital.service.AppointmentService;
import com.hospital.service.UserService;

@Controller
public class CommonController {

	private UserService userService;
	private AppointmentService appointmentService;

	@Autowired
	public CommonController(UserService userService, AppointmentService appointmentService) {
		this.userService = userService;
		this.appointmentService = appointmentService;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home() {
		// this creates a model and view with home as the view so that home.html can be
		// displayed
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("home");
		return modelAndView;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login() {
		// this creates a model and view with login as the view so that login.html can
		// be displayed
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}

	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public ModelAndView registration() {
		// this creates a model and view with registration as the view so that
		// registration.html can be displayed
		// also it adds a model user which is needed by the html
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("registration");
		return modelAndView;
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView createNewUser(User user, BindingResult bindingResult) {
		// once the registration request is fired. it checks if the user with given
		// username is present or not
		// if its present then error is thrown otherwise the user is registered.
		ModelAndView modelAndView = new ModelAndView();
		User userExists = userService.findUserByUserName(user.getUserName());
		if (userExists != null) {
			bindingResult.rejectValue("userName", "error.user",
					"There is already a user registered with the user name provided");
		}
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("registration");
		} else {
			userService.saveUser(user);
			modelAndView.addObject("successMessage", "User has been registered successfully");
			modelAndView.addObject("user", new User());
			modelAndView.setViewName("registration");

		}
		return modelAndView;
	}

	@RequestMapping(value = { "/home" }, method = RequestMethod.GET)
	public ModelAndView getHomePage() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = ((UserDetails) auth.getPrincipal());

		// this method is used to get the home page of doctor or patient based on the
		// role of the user
		if (auth != null && auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("DOCTOR"))) {
			ModelAndView modelAndView = new ModelAndView();
			long userId = userService.findUserByUserName(userDetails.getUsername()).getId();
			modelAndView.addObject("temporary", new Appointment());
			modelAndView.addObject("showMessage", false);
			modelAndView.addObject("appointmentList", appointmentService.findDoctorAppointments(userId));
			modelAndView.setViewName("doctorHome");
			return modelAndView;
		} else {
			ModelAndView modelAndView = new ModelAndView();
			Appointment appointment = new Appointment();
			long userId = userService.findUserByUserName(userDetails.getUsername()).getId();
			appointment.setPatientId(userId);
			modelAndView.addObject("appointment", appointment);
			modelAndView.addObject("doctorList", userService.getAllDoctors());
			modelAndView.addObject("appointmentList", appointmentService.findPatientAppointments(userId));
			modelAndView.setViewName("patientHome");
			return modelAndView;
		}
	}

	@GetMapping("check/{id}")
	public ModelAndView searchAppointment(@PathVariable("id") long id, ModelAndView modelAndView) {
		// this is used to fetch appointment for the doctor
		modelAndView.addObject("appointment", appointmentService.findById(id));
		modelAndView.setViewName("appointment");
		return modelAndView;
	}

	@RequestMapping(value = "/add-appointment", method = RequestMethod.POST)
	public ModelAndView addAppointment(Appointment appointment, ModelAndView modelAndView) {

		// this is used to register a patient appointment request in the database
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = ((UserDetails) auth.getPrincipal());

		boolean result = appointmentService.addAppointment(appointment);

		Appointment appointmentDetails = new Appointment();
		long userId = userService.findUserByUserName(userDetails.getUsername()).getId();
		appointment.setPatientId(userId);

		modelAndView.addObject("appointment", appointmentDetails);
		modelAndView.addObject("doctorList", userService.getAllDoctors());
		modelAndView.addObject("appointmentList", appointmentService.findPatientAppointments(userId));
		modelAndView.addObject("showMessage", true);
		if (result) {
			modelAndView.addObject("message", "Appointment Added Successfully!");
		} else {
			modelAndView.addObject("message", "Appointment already present for the same doctor!");
		}

		modelAndView.setViewName("patientHome");
		return modelAndView;

	}

	@RequestMapping(value = "/appointment", method = RequestMethod.POST)
	public ModelAndView appointment(Appointment appointment, ModelAndView modelAndView) {
		// this method is used to add comments and feedback to a patient appointment
		// from the doctor page.
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = ((UserDetails) auth.getPrincipal());

		appointmentService.addAppointmentForDoctor(appointment);

		long userId = userService.findUserByUserName(userDetails.getUsername()).getId();
		appointment.setPatientId(userId);

		modelAndView.addObject("appointmentList", appointmentService.findDoctorAppointments(userId));
		modelAndView.addObject("showMessage", true);
		modelAndView.addObject("temporary", new Appointment());
		modelAndView.addObject("message", "Appointment Completed Successfully!");
		modelAndView.setViewName("doctorHome");
		return modelAndView;

	}

}