package com.hospital.exception;

public class NoDoctorFoundException extends RuntimeException{
    public NoDoctorFoundException(String message) {
        super(message);
    }
}
