package com.hospital.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hospital.entity.Appointment;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
	List<Appointment> findByPatientIdAndAppointmentDone(long patientId, boolean appointmentDone);

	List<Appointment> findByPatientIdAndDoctorIdAndAppointmentDone(long patientId, long doctorId,
			boolean appointmentDone);

	List<Appointment> findByDoctorIdAndAppointmentDone(long doctorId, boolean appointmentDone);
}
