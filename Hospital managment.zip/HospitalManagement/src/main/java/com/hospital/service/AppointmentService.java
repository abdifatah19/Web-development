package com.hospital.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.entity.Appointment;
import com.hospital.entity.AppointmentDTO;
import com.hospital.entity.User;
import com.hospital.repository.AppointmentRepository;
import com.hospital.repository.UserRepository;

@Service
public class AppointmentService {

	private AppointmentRepository appointmentRepository;
	private UserRepository userRepository;

	@Autowired
	public AppointmentService(AppointmentRepository appointmentRepository, UserRepository userRepository) {
		this.appointmentRepository = appointmentRepository;
		this.userRepository = userRepository;
	}

	public boolean addAppointment(Appointment appointment) {
		List<Appointment> result = appointmentRepository.findByPatientIdAndDoctorIdAndAppointmentDone(
				appointment.getPatientId(), appointment.getDoctorId(), false);
		if (result.size() > 0) {
			return false;
		}
		appointment.setAppointmentDone(false);
		appointmentRepository.save(appointment);
		return true;
	}

	public void addAppointmentForDoctor(Appointment appointment) {
		appointment.setAppointmentDone(true);
		appointmentRepository.save(appointment);
	}

	public Appointment findById(Long id) {
		return appointmentRepository.findById(id).get();
	}

	// it is used to fetch the appointment based on the patient id. The appointments
	// are then converted in to appointmentsDTO
	// so that the additional information such as patientName and doctorName can be
	// displayed on the html
	public List<AppointmentDTO> findPatientAppointments(long patientID) {
		List<Appointment> appointments = appointmentRepository.findByPatientIdAndAppointmentDone(patientID, true);
		List<AppointmentDTO> result = new ArrayList<>();
		appointments.forEach(appointment -> {
			AppointmentDTO appointmentDTO = new AppointmentDTO();
			appointmentDTO.setPatientName(userRepository.findById(appointment.getPatientId()).get().getName());
			appointmentDTO.setDoctorName(userRepository.findById(appointment.getDoctorId()).get().getName());
			appointmentDTO.setComments(appointment.getComments());
			appointmentDTO.setMedicinesPrescribed(appointment.getMedicinesPrescribed());
			result.add(appointmentDTO);
		});

		return result;
	}

	// this is used to fetch all the appointments related to doctor. The data for
	// comments and medicinePrescribed are set
	// to NOT PROVIDED.
	public List<AppointmentDTO> findDoctorAppointments(long doctorId) {
		List<Appointment> appointments = appointmentRepository.findByDoctorIdAndAppointmentDone(doctorId, false);
		List<AppointmentDTO> result = new ArrayList<>();
		appointments.forEach(appointment -> {
			AppointmentDTO appointmentDTO = new AppointmentDTO();
			Optional<User> patient = userRepository.findById(appointment.getPatientId());
			if (patient.isPresent()) {
				appointmentDTO.setPatientName(patient.get().getName());
				appointmentDTO.setDoctorName(userRepository.findById(appointment.getDoctorId()).get().getName());
				appointmentDTO.setComments("NOT PROVIDED");
				appointmentDTO.setMedicinesPrescribed("NOT PROVIDED");
				appointmentDTO.setId(appointment.getId());
				appointmentDTO.setTime(appointment.getTime());
				result.add(appointmentDTO);
			}
		});

		return result;
	}
}
