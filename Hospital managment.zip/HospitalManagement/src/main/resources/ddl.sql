CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
);

CREATE TABLE `user_role` (
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
);

CREATE TABLE `roles` (
  `role_id` int NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
);

CREATE TABLE `appointment` (
  `id` bigint NOT NULL,
  `appointment_done` bit(1) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `doctor_id` bigint NOT NULL,
  `medicines_prescribed` varchar(255) DEFAULT NULL,
  `patient_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
);