package com.hospital.controller;

import com.hospital.entity.Appointment;
import com.hospital.service.AppointmentService;
import com.hospital.service.UserService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.ModelAndView;

import static org.mockito.ArgumentMatchers.anyLong;

public class CommonControllerTest {

    @Mock
    private UserService userService;
    @Mock
    private AppointmentService appointmentService;

    private CommonController controller;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
        controller = new CommonController(userService, appointmentService);
    }

    @Test
    public void testHomePage() {
        ModelAndView modelAndView = controller.home();
        Assertions.assertEquals("home", modelAndView.getViewName());

    }

    @Test
    public void testLoginPage() {
        ModelAndView modelAndView = controller.login();
        Assertions.assertEquals("login", modelAndView.getViewName());

    }

    @Test
    public void testRegistrationPage() {
        ModelAndView modelAndView = controller.registration();
        Assertions.assertEquals("registration", modelAndView.getViewName());

    }

    @Test
    public void testSearchAppointment() {
        Mockito.when(appointmentService.findById(anyLong())).thenReturn(new Appointment());
        ModelAndView modelAndView = new ModelAndView();

        ModelAndView output = controller.searchAppointment(1L, modelAndView);
        Assertions.assertEquals("appointment", output.getViewName());
    }
}
