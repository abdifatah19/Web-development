package com.hospital.service;

import com.hospital.entity.Appointment;
import com.hospital.entity.AppointmentDTO;
import com.hospital.repository.AppointmentRepository;
import com.hospital.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;

public class AppointmentServiceTest {

    @Mock
    private AppointmentRepository appointmentRepository;
    @Mock
    private UserRepository userRepository;

    private AppointmentService appointmentService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
        appointmentService = new AppointmentService(appointmentRepository, userRepository);
    }

    @Test
    public void testFindPatientAppointment() {
        List<Appointment> appointmentList = new ArrayList<>();
        Mockito.when(appointmentRepository.findByPatientIdAndAppointmentDone(anyLong(), anyBoolean())).thenReturn(appointmentList);

        List<AppointmentDTO> output = appointmentService.findPatientAppointments(1L);

        Assertions.assertEquals(0, output.size());
    }
}
