package com.hospital.service;

import com.hospital.entity.Role;
import com.hospital.entity.User;
import com.hospital.repository.RoleRepository;
import com.hospital.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;

public class UserServiceTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private RoleRepository roleRepository;
    @Mock
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    private UserService userService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
        userService = new UserService(userRepository, roleRepository, bCryptPasswordEncoder);
    }

    @Test
    public void testGetAllDoctors() {
        Mockito.when(roleRepository.findByRole("DOCTOR")).thenReturn(new Role());
        List<User> users = new ArrayList<>();
        users.add(new User());
        Mockito.when(userRepository.findByRoles(any())).thenReturn(users);

        List<User> output = userService.getAllDoctors();
        Assertions.assertEquals(1, output.size());
    }
}
